# JavaScript Lab 2 Part 2
## Samantha Stutzman
