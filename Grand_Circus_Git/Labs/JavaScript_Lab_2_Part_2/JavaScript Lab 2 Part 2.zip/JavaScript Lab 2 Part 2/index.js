" use strict ";



//Call the fight function with the required four parameters
//You pick the names and starting health.
//player1: “Mitch”, player2: “Adam”, player1Health: 100, player2Health: 100

fight ( "Mitch", "Adam", 100, 100 );